# Architecture and design decisions

## Why these choices
- **Django**: batteries included (auth, ORM, migrations, admin). The admin site doubles as the user-management tool, so no custom admin UI was needed.
- **GraphQL (Strawberry)**: the dashboard needs tickets, comments and SLA figures in one round trip, and clients ask only for the fields they need. REST is used in the companion project, so the two show both styles.
- **Thin schema, fat services**: `schema.py` maps GraphQL to Python types; business rules live in `services.py` and `sla.py`. The SLA rules are pure functions with no database access, so they are tested directly.
- **PostgreSQL + MongoDB**: tickets, users and comments are relational and need integrity. Audit entries are append-only documents with free-form `details`, a good fit for a document store. The `AuditLog` interface lets tests and local runs use an in-memory implementation.
- **Pinia**: small stores for auth and tickets; components stay presentational. The API layer is one typed `gql()` function.
- **nginx front door**: single origin for the browser, so no CORS in production.

## Data model
`Ticket(title, description, priority, status, requester, assignee, created_at, sla_due_at, resolved_at)`
`Comment(ticket, author, body, created_at)` · Django `User` (`is_staff` = agent)
Mongo `audit_log {ticket_id, actor, action, details, at}` indexed on `(ticket_id, at)`.

## SLA rules
`sla_due_at = created_at + SLA_HOURS[priority]`, fixed at creation. Resolved tickets are judged by `resolved_at` vs deadline (so a late resolution is never "forgotten"); open tickets by the current time. Reopening clears `resolved_at`. Compliance = resolved-on-time ÷ resolved.

## Request flow (agent resolves a ticket)
1. SPA sends `updateTicketStatus` with the bearer token.
2. The view builds a context with the user from the token; the `IsAgent` permission class runs.
3. `change_status` locks the row (`select_for_update`), updates status and `resolved_at`, and writes an audit entry, inside one transaction.
4. The store reloads the list and the SLA report.

## Scaling notes
- Backend is stateless (JWT) and scales horizontally; Gunicorn workers are configurable.
- `sla_report` currently loads minimal columns and aggregates in Python; at large volumes replace it with SQL aggregates (`COUNT ... FILTER`).
- Audit writes could move to a queue if Mongo latency becomes a concern.
