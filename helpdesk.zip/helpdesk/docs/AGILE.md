# Agile working agreement

## Definition of done
- PR reviewed by one other developer
- Tests added/updated; CI green (including the missing-migrations check)
- No secrets in code; inputs validated; permissions covered by a test
- README/docs updated when behaviour changes

## Sprint 1 backlog (example)

| Story | Acceptance criteria | Status |
|---|---|---|
| As a requester I can log a ticket with a priority | Title ≥ 3 chars; description required; SLA deadline set from priority | Done |
| As a requester I only see my own tickets | Other users' tickets are invisible, by list and by id | Done |
| As an agent I can start and resolve tickets | Starting self-assigns; resolving records the time; reopening clears it | Done |
| As an agent I can see SLA compliance | Dashboard shows open, breached, resolved and compliance % | Done |
| As a manager I can see who changed what | Audit trail of create/status/comment events, agents only | Done |
| As a developer I get fast CI feedback | Tests, migration check, type-check and build on every PR | Done |

## Sprint 2 candidates
- Auto-escalation at 80% of SLA time
- Email notifications
- Pagination controls and saved filters
- Replace Python aggregation in the SLA report with SQL

## Ceremonies
Sprint planning · daily stand-up · sprint review with stakeholders · retrospective with one improvement action.
