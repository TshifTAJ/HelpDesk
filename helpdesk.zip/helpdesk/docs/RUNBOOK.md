# Runbook: troubleshooting and root cause analysis

## First checks
1. `GET /health` returns `{"status":"ok"}` (proves the Postgres connection).
2. `docker compose ps`: all services running; `db` and `mongo` healthy.
3. `docker compose logs backend --tail 100`.

## Common problems
| Symptom | Likely cause | Fix |
|---|---|---|
| Backend exits at startup with "DJANGO_SECRET_KEY must be set" | Missing `.env` value | Fill in `.env` |
| `Authentication required` on every call | Token expired or `DJANGO_SECRET_KEY` changed | Sign in again; keep the key stable |
| Audit trail empty in production | `MONGO_URL` unset (in-memory store in use) | Set `MONGO_URL` and restart |
| Admin pages unstyled | Static files not collected | Rebuild the backend image (`collectstatic` runs at build) |
| Slow ticket list | Missing index or N+1 | Check `ticket_*_idx` indexes; the query-count test should fail first |
| Tests fail on Postgres only | Dialect difference | Run `pytest` with `POSTGRES_*` set |

## RCA template
- **What happened / impact / duration**
- **Timeline**
- **Root cause** (keep asking why)
- **Corrective** and **preventive** actions (usually a new test or alert)
- **Owner and date**
