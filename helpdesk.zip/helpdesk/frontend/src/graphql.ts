export class GraphQLClientError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'GraphQLClientError'
  }
}

interface GraphQLResponse<T> {
  data?: T
  errors?: { message: string }[]
}

/** Send one GraphQL operation. Throws GraphQLClientError with the server's message on failure. */
export async function gql<T>(
  query: string,
  variables: Record<string, unknown> = {},
  token?: string | null,
): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  if (token) headers.Authorization = `Bearer ${token}`

  let res: Response
  try {
    res = await fetch('/graphql', { method: 'POST', headers, body: JSON.stringify({ query, variables }) })
  } catch {
    throw new GraphQLClientError('Could not reach the server')
  }

  const body = (await res.json().catch(() => ({}))) as GraphQLResponse<T>
  if (body.errors?.length) throw new GraphQLClientError(body.errors.map((e) => e.message).join('; '))
  if (!res.ok || !body.data) throw new GraphQLClientError(`Request failed (${res.status})`)
  return body.data
}
