<script setup lang="ts">
import LoginView from './components/LoginView.vue'
import SlaDashboard from './components/SlaDashboard.vue'
import TicketForm from './components/TicketForm.vue'
import TicketList from './components/TicketList.vue'
import { useAuthStore } from './stores/auth'

const auth = useAuthStore()
</script>

<template>
  <main class="min-h-screen bg-slate-100 text-slate-900">
    <LoginView v-if="!auth.isLoggedIn" />
    <div v-else class="mx-auto max-w-5xl space-y-6 p-6">
      <header class="flex items-center justify-between">
        <h1 class="text-2xl font-bold">HelpDesk</h1>
        <button class="text-sm text-teal-800 underline" @click="auth.logout()">
          Sign out ({{ auth.session?.username }})
        </button>
      </header>
      <SlaDashboard v-if="auth.isAgent" />
      <div class="grid gap-6 md:grid-cols-3">
        <section class="rounded-xl bg-white p-4 shadow md:col-span-2">
          <h2 class="mb-3 font-semibold">Tickets</h2>
          <TicketList />
        </section>
        <TicketForm />
      </div>
    </div>
  </main>
</template>
