export type Priority = 'low' | 'medium' | 'high' | 'urgent'
export type Status = 'open' | 'in_progress' | 'resolved'

export interface Ticket {
  id: string
  title: string
  description: string
  priority: Priority
  status: Status
  requester: string
  assignee: string | null
  createdAt: string
  slaDueAt: string
  resolvedAt: string | null
  slaBreached: boolean
}

export interface SlaReport {
  total: number
  open: number
  breachedOpen: number
  resolved: number
  compliancePercent: number
}
