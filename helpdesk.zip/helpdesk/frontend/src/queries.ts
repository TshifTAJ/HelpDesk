const TICKET_FIELDS = `
  id title description priority status requester assignee
  createdAt slaDueAt resolvedAt slaBreached
`

export const LOGIN = `
  mutation ($username: String!, $password: String!) {
    login(username: $username, password: $password) { token username isAgent }
  }`

export const TICKETS = `
  query ($status: String, $search: String, $page: Int) {
    tickets(status: $status, search: $search, page: $page, pageSize: 10) {
      total page pageSize items { ${TICKET_FIELDS} }
    }
  }`

export const CREATE_TICKET = `
  mutation ($title: String!, $description: String!, $priority: String!) {
    createTicket(title: $title, description: $description, priority: $priority) { ${TICKET_FIELDS} }
  }`

export const UPDATE_STATUS = `
  mutation ($id: ID!, $status: String!) {
    updateTicketStatus(id: $id, status: $status) { ${TICKET_FIELDS} }
  }`

export const SLA_REPORT = `
  query { slaReport { total open breachedOpen resolved compliancePercent } }`
