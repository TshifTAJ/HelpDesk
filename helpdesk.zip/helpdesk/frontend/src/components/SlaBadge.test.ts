import { mount } from '@vue/test-utils'
import SlaBadge from './SlaBadge.vue'

describe('SlaBadge', () => {
  it.each([
    [false, 'open', 'Within SLA'],
    [true, 'open', 'SLA breached'],
    [false, 'resolved', 'Met SLA'],
    [true, 'resolved', 'Resolved late'],
  ] as const)('breached=%s status=%s shows "%s"', (breached, status, label) => {
    const wrapper = mount(SlaBadge, { props: { breached, status } })
    expect(wrapper.text()).toBe(label)
  })

  it('uses red styling when breached', () => {
    const wrapper = mount(SlaBadge, { props: { breached: true, status: 'open' } })
    expect(wrapper.classes().join(' ')).toContain('red')
  })
})
