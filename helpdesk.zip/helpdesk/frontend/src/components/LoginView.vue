<script setup lang="ts">
import { ref } from 'vue'
import { useAuthStore } from '../stores/auth'
import { GraphQLClientError } from '../graphql'

const auth = useAuthStore()
const username = ref('')
const password = ref('')
const error = ref<string | null>(null)
const busy = ref(false)

async function submit() {
  busy.value = true
  error.value = null
  try {
    await auth.login(username.value, password.value)
  } catch (err) {
    error.value = err instanceof GraphQLClientError ? err.message : 'Something went wrong'
  } finally {
    busy.value = false
  }
}
</script>

<template>
  <form class="mx-auto mt-24 w-full max-w-sm space-y-4 rounded-xl bg-white p-6 shadow" @submit.prevent="submit">
    <h1 class="text-xl font-bold">HelpDesk sign in</h1>
    <label class="block text-sm font-medium">
      Username
      <input v-model="username" class="mt-1 w-full rounded border border-slate-300 px-3 py-2" required />
    </label>
    <label class="block text-sm font-medium">
      Password
      <input v-model="password" type="password" class="mt-1 w-full rounded border border-slate-300 px-3 py-2" required />
    </label>
    <p v-if="error" role="alert" class="text-sm text-red-700">{{ error }}</p>
    <button :disabled="busy" class="w-full rounded bg-teal-700 px-4 py-2 font-semibold text-white disabled:opacity-50">
      {{ busy ? 'Signing in…' : 'Sign in' }}
    </button>
  </form>
</template>
