import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import TicketForm from './TicketForm.vue'

const TICKETS_EMPTY = { data: { tickets: { items: [], total: 0, page: 1, pageSize: 10 } } }

function json(body: unknown) {
  return new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } })
}

beforeEach(() => setActivePinia(createPinia()))
afterEach(() => vi.unstubAllGlobals())

async function fill(wrapper: ReturnType<typeof mount>) {
  await wrapper.find('input').setValue('Printer jammed')
  await wrapper.find('textarea').setValue('Paper stuck in tray 2')
  await wrapper.find('select').setValue('high')
}

describe('TicketForm', () => {
  it('submits the ticket then clears the form', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(json({ data: { createTicket: { id: '1' } } }))
      .mockResolvedValue(json(TICKETS_EMPTY))
    vi.stubGlobal('fetch', fetchMock)

    const wrapper = mount(TicketForm)
    await fill(wrapper)
    await wrapper.find('form').trigger('submit')
    await flushPromises()

    const sent = JSON.parse(fetchMock.mock.calls[0][1].body)
    expect(sent.variables).toEqual({ title: 'Printer jammed', description: 'Paper stuck in tray 2', priority: 'high' })
    expect((wrapper.find('input').element as HTMLInputElement).value).toBe('')
  })

  it('shows the server validation message and keeps the input', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(json({ errors: [{ message: 'Title must be at least 3 characters' }] })))

    const wrapper = mount(TicketForm)
    await fill(wrapper)
    await wrapper.find('form').trigger('submit')
    await flushPromises()

    expect(wrapper.find('[role=alert]').text()).toBe('Title must be at least 3 characters')
    expect((wrapper.find('input').element as HTMLInputElement).value).toBe('Printer jammed')
  })
})
