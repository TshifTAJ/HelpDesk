<script setup lang="ts">
import { ref } from 'vue'
import { GraphQLClientError } from '../graphql'
import { useTicketStore } from '../stores/tickets'
import type { Priority } from '../types'

const store = useTicketStore()
const title = ref('')
const description = ref('')
const priority = ref<Priority>('medium')
const error = ref<string | null>(null)

async function submit() {
  error.value = null
  try {
    await store.create(title.value, description.value, priority.value)
    title.value = ''
    description.value = ''
    priority.value = 'medium'
  } catch (err) {
    error.value = err instanceof GraphQLClientError ? err.message : 'Could not create ticket'
  }
}
</script>

<template>
  <form class="space-y-3 rounded-xl bg-white p-4 shadow" @submit.prevent="submit">
    <h2 class="font-semibold">New ticket</h2>
    <label class="block text-sm font-medium">
      Title
      <input v-model="title" class="mt-1 w-full rounded border border-slate-300 px-3 py-2" required />
    </label>
    <label class="block text-sm font-medium">
      Description
      <textarea v-model="description" rows="3" class="mt-1 w-full rounded border border-slate-300 px-3 py-2" required />
    </label>
    <label class="block text-sm font-medium">
      Priority
      <select v-model="priority" class="mt-1 w-full rounded border border-slate-300 px-3 py-2">
        <option value="low">Low (72h SLA)</option>
        <option value="medium">Medium (24h SLA)</option>
        <option value="high">High (8h SLA)</option>
        <option value="urgent">Urgent (4h SLA)</option>
      </select>
    </label>
    <p v-if="error" role="alert" class="text-sm text-red-700">{{ error }}</p>
    <button class="rounded bg-teal-700 px-4 py-2 font-semibold text-white">Submit</button>
  </form>
</template>
