<script setup lang="ts">
import { useTicketStore } from '../stores/tickets'

const store = useTicketStore()
</script>

<template>
  <section v-if="store.report" class="grid grid-cols-2 gap-3 md:grid-cols-4">
    <div class="rounded-xl bg-white p-4 shadow">
      <p class="text-xs text-slate-500">Open tickets</p>
      <p class="text-2xl font-bold">{{ store.report.open }}</p>
    </div>
    <div class="rounded-xl bg-white p-4 shadow">
      <p class="text-xs text-slate-500">Open and breached</p>
      <p class="text-2xl font-bold" :class="store.report.breachedOpen > 0 ? 'text-red-700' : ''">
        {{ store.report.breachedOpen }}
      </p>
    </div>
    <div class="rounded-xl bg-white p-4 shadow">
      <p class="text-xs text-slate-500">Resolved</p>
      <p class="text-2xl font-bold">{{ store.report.resolved }}</p>
    </div>
    <div class="rounded-xl bg-white p-4 shadow">
      <p class="text-xs text-slate-500">SLA compliance</p>
      <p class="text-2xl font-bold">{{ store.report.compliancePercent }}%</p>
    </div>
  </section>
</template>
