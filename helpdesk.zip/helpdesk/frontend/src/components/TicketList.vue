<script setup lang="ts">
import { onMounted, watch } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useTicketStore } from '../stores/tickets'
import type { Status } from '../types'
import SlaBadge from './SlaBadge.vue'

const auth = useAuthStore()
const store = useTicketStore()

onMounted(() => store.load())

// Debounce the search box so we don't query on every keystroke.
let timer: ReturnType<typeof setTimeout> | undefined
watch(
  () => store.search,
  () => {
    clearTimeout(timer)
    timer = setTimeout(() => store.load(), 250)
  },
)
watch(() => store.statusFilter, () => store.load())

const NEXT: Record<Status, { to: Status; label: string }> = {
  open: { to: 'in_progress', label: 'Start' },
  in_progress: { to: 'resolved', label: 'Resolve' },
  resolved: { to: 'open', label: 'Reopen' },
}
</script>

<template>
  <div class="space-y-3">
    <div class="flex gap-2">
      <input v-model="store.search" aria-label="Search tickets" placeholder="Search tickets"
        class="flex-1 rounded border border-slate-300 px-3 py-2" />
      <select v-model="store.statusFilter" aria-label="Filter by status" class="rounded border border-slate-300 px-3 py-2">
        <option value="">All</option>
        <option value="open">Open</option>
        <option value="in_progress">In progress</option>
        <option value="resolved">Resolved</option>
      </select>
    </div>

    <p v-if="store.error" role="alert" class="text-sm text-red-700">{{ store.error }}</p>
    <p v-else-if="store.loading">Loading…</p>
    <p v-else-if="store.items.length === 0">No tickets found.</p>

    <ul class="divide-y divide-slate-200">
      <li v-for="t in store.items" :key="t.id" class="flex items-center justify-between gap-3 py-3">
        <div>
          <p class="font-medium">#{{ t.id }} {{ t.title }}</p>
          <p class="text-xs text-slate-500">
            {{ t.priority }} · {{ t.status.replace('_', ' ') }} · by {{ t.requester }}
            <template v-if="t.assignee">· assigned to {{ t.assignee }}</template>
          </p>
        </div>
        <div class="flex items-center gap-2">
          <SlaBadge :breached="t.slaBreached" :status="t.status" />
          <button v-if="auth.isAgent" class="rounded border border-teal-700 px-2 py-1 text-xs text-teal-800"
            @click="store.setStatus(t.id, NEXT[t.status].to)">
            {{ NEXT[t.status].label }}
          </button>
        </div>
      </li>
    </ul>
    <p class="text-xs text-slate-500">{{ store.total }} ticket(s)</p>
  </div>
</template>
