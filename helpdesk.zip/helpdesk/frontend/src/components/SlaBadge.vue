<script setup lang="ts">
import { computed } from 'vue'
import type { Status } from '../types'

const props = defineProps<{ breached: boolean; status: Status }>()

const label = computed(() => {
  if (props.breached) return props.status === 'resolved' ? 'Resolved late' : 'SLA breached'
  return props.status === 'resolved' ? 'Met SLA' : 'Within SLA'
})
const style = computed(() => (props.breached ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'))
</script>

<template>
  <span :class="['rounded-full px-2 py-0.5 text-xs font-semibold', style]">{{ label }}</span>
</template>
