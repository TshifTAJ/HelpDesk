import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '../stores/auth'
import TicketList from './TicketList.vue'

const ticket = {
  id: '5', title: 'VPN down', description: 'x', priority: 'urgent', status: 'open', requester: 'alice',
  assignee: null, createdAt: '2026-01-01T08:00:00Z', slaDueAt: '2026-01-01T12:00:00Z', resolvedAt: null, slaBreached: true,
}

function stubTickets() {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockImplementation(async (_url: string, init: RequestInit) => {
      const query = JSON.parse(init.body as string).query as string
      const data = query.includes('slaReport')
        ? { slaReport: { total: 1, open: 1, breachedOpen: 1, resolved: 0, compliancePercent: 100 } }
        : { tickets: { items: [ticket], total: 1, page: 1, pageSize: 10 } }
      return new Response(JSON.stringify({ data }), { status: 200, headers: { 'Content-Type': 'application/json' } })
    }),
  )
}

function mountAs(isAgent: boolean) {
  setActivePinia(createPinia())
  useAuthStore().session = { token: 't', username: 'u', isAgent }
  return mount(TicketList)
}

afterEach(() => vi.unstubAllGlobals())

describe('TicketList', () => {
  it('shows tickets with an SLA badge', async () => {
    stubTickets()
    const wrapper = mountAs(false)
    await flushPromises()

    expect(wrapper.text()).toContain('VPN down')
    expect(wrapper.text()).toContain('SLA breached')
  })

  it('only agents get workflow buttons', async () => {
    stubTickets()
    const requester = mountAs(false)
    await flushPromises()
    expect(requester.findAll('button')).toHaveLength(0)

    const agent = mountAs(true)
    await flushPromises()
    expect(agent.find('button').text()).toBe('Start')
  })

  it('shows an empty state', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ data: { tickets: { items: [], total: 0, page: 1, pageSize: 10 } } }), { status: 200 }),
      ),
    )
    const wrapper = mountAs(false)
    await flushPromises()
    expect(wrapper.text()).toContain('No tickets found.')
  })
})
