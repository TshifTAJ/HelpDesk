import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from './auth'

function mockLogin(isAgent: boolean) {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ data: { login: { token: 't', username: 'sam', isAgent } } }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      }),
    ),
  )
}

beforeEach(() => {
  sessionStorage.clear()
  setActivePinia(createPinia())
})
afterEach(() => vi.unstubAllGlobals())

describe('auth store', () => {
  it('logs in, exposes role getters and persists the session', async () => {
    mockLogin(true)
    const auth = useAuthStore()
    await auth.login('sam', 'pw')

    expect(auth.isLoggedIn).toBe(true)
    expect(auth.isAgent).toBe(true)
    expect(auth.token).toBe('t')
    expect(sessionStorage.getItem('helpdesk.session')).toContain('sam')
  })

  it('requesters are not agents', async () => {
    mockLogin(false)
    const auth = useAuthStore()
    await auth.login('sam', 'pw')
    expect(auth.isAgent).toBe(false)
  })

  it('logout clears state and storage', async () => {
    mockLogin(true)
    const auth = useAuthStore()
    await auth.login('sam', 'pw')
    auth.logout()

    expect(auth.isLoggedIn).toBe(false)
    expect(sessionStorage.getItem('helpdesk.session')).toBeNull()
  })

  it('failed login leaves the user logged out', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ errors: [{ message: 'Incorrect username or password' }] }), { status: 200 }),
      ),
    )
    const auth = useAuthStore()
    await expect(auth.login('x', 'y')).rejects.toThrow('Incorrect username or password')
    expect(auth.isLoggedIn).toBe(false)
  })
})
