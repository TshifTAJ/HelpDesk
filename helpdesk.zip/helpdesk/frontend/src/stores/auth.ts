import { defineStore } from 'pinia'
import { gql } from '../graphql'
import { LOGIN } from '../queries'

const KEY = 'helpdesk.session'

interface Session {
  token: string
  username: string
  isAgent: boolean
}

function load(): Session | null {
  try {
    const raw = sessionStorage.getItem(KEY)
    return raw ? (JSON.parse(raw) as Session) : null
  } catch {
    return null
  }
}

export const useAuthStore = defineStore('auth', {
  state: () => ({ session: load() as Session | null }),
  getters: {
    isLoggedIn: (state) => state.session !== null,
    isAgent: (state) => state.session?.isAgent ?? false,
    token: (state) => state.session?.token ?? null,
  },
  actions: {
    async login(username: string, password: string) {
      const data = await gql<{ login: Session }>(LOGIN, { username, password })
      this.session = data.login
      sessionStorage.setItem(KEY, JSON.stringify(data.login))
    },
    logout() {
      this.session = null
      sessionStorage.removeItem(KEY)
    },
  },
})
