import { defineStore } from 'pinia'
import { GraphQLClientError, gql } from '../graphql'
import { CREATE_TICKET, SLA_REPORT, TICKETS, UPDATE_STATUS } from '../queries'
import type { Priority, SlaReport, Status, Ticket } from '../types'
import { useAuthStore } from './auth'

function messageOf(err: unknown): string {
  return err instanceof GraphQLClientError ? err.message : 'Something went wrong'
}

export const useTicketStore = defineStore('tickets', {
  state: () => ({
    items: [] as Ticket[],
    total: 0,
    report: null as SlaReport | null,
    loading: false,
    error: null as string | null,
    statusFilter: '' as Status | '',
    search: '',
  }),
  actions: {
    async load() {
      const auth = useAuthStore()
      this.loading = true
      this.error = null
      try {
        const data = await gql<{ tickets: { items: Ticket[]; total: number } }>(
          TICKETS,
          { status: this.statusFilter || null, search: this.search || null, page: 1 },
          auth.token,
        )
        this.items = data.tickets.items
        this.total = data.tickets.total
        if (auth.isAgent) {
          this.report = (await gql<{ slaReport: SlaReport }>(SLA_REPORT, {}, auth.token)).slaReport
        }
      } catch (err) {
        this.error = messageOf(err)
      } finally {
        this.loading = false
      }
    },
    async create(title: string, description: string, priority: Priority) {
      const auth = useAuthStore()
      await gql(CREATE_TICKET, { title, description, priority }, auth.token)
      await this.load()
    },
    async setStatus(id: string, status: Status) {
      const auth = useAuthStore()
      try {
        await gql(UPDATE_STATUS, { id, status }, auth.token)
        await this.load()
      } catch (err) {
        this.error = messageOf(err)
      }
    },
  },
})
