import { GraphQLClientError, gql } from './graphql'

function respond(status: number, body: unknown) {
  const fn = vi.fn().mockResolvedValue(
    new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } }),
  )
  vi.stubGlobal('fetch', fn)
  return fn
}

afterEach(() => vi.unstubAllGlobals())

describe('gql client', () => {
  it('returns data and sends the bearer token', async () => {
    const fetchMock = respond(200, { data: { hello: 'world' } })
    const data = await gql<{ hello: string }>('{ hello }', { a: 1 }, 'tok')

    expect(data.hello).toBe('world')
    const [url, init] = fetchMock.mock.calls[0]
    expect(url).toBe('/graphql')
    expect(init.headers.Authorization).toBe('Bearer tok')
    expect(JSON.parse(init.body)).toEqual({ query: '{ hello }', variables: { a: 1 } })
  })

  it('omits the Authorization header when there is no token', async () => {
    const fetchMock = respond(200, { data: {} })
    await gql('{ x }')
    expect(fetchMock.mock.calls[0][1].headers.Authorization).toBeUndefined()
  })

  it('throws the server message for GraphQL errors', async () => {
    respond(200, { errors: [{ message: 'Agent role required' }] })
    await expect(gql('{ x }')).rejects.toThrow('Agent role required')
  })

  it('wraps network failures in a friendly error', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('failed')))
    const err: unknown = await gql('{ x }').catch((e: unknown) => e)
    expect(err).toBeInstanceOf(GraphQLClientError)
    expect((err as Error).message).toBe('Could not reach the server')
  })
})
