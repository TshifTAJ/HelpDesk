/// <reference types="vitest/config" />
import tailwindcss from '@tailwindcss/vite'
import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue(), tailwindcss()],
  server: {
    // Proxy GraphQL to Django in dev so the browser sees a single origin.
    proxy: { '/graphql': 'http://localhost:8000' },
  },
  test: {
    environment: 'jsdom',
    globals: true,
  },
})
