from django.contrib import admin
from django.http import JsonResponse
from django.urls import path
from django.views.decorators.csrf import csrf_exempt

from tickets.views import HelpDeskGraphQLView
from tickets.schema import schema


def health(_request):
    from django.db import connection

    with connection.cursor() as cursor:
        cursor.execute("SELECT 1")
    return JsonResponse({"status": "ok"})


urlpatterns = [
    path("admin/", admin.site.urls),
    path("health", health),
    # Auth is a bearer token in the Authorization header (not a cookie), so CSRF does not apply here.
    path("graphql", csrf_exempt(HelpDeskGraphQLView.as_view(schema=schema))),
]
