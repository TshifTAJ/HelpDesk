"""Settings for the test suite: same as production settings plus a throwaway secret key."""
import os

os.environ.setdefault("DJANGO_SECRET_KEY", "test-secret-key-that-is-at-least-32-bytes-long")
os.environ.pop("MONGO_URL", None)  # tests use the in-memory audit log

from .settings import *  # noqa: E402,F401,F403
