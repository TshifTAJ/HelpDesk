"""Audit trail of who did what to which ticket.

Audit entries are append-only, schema-flexible documents, which suits a document store (MongoDB)
better than relational tables. In tests and quick local runs an in-memory store is used instead.
"""
from datetime import datetime, timezone
from functools import lru_cache
from typing import Protocol

from django.conf import settings


class AuditLog(Protocol):
    def record(self, ticket_id: int, actor: str, action: str, details: dict | None = None) -> None: ...
    def trail(self, ticket_id: int) -> list[dict]: ...


def _entry(ticket_id: int, actor: str, action: str, details: dict | None) -> dict:
    return {
        "ticket_id": ticket_id,
        "actor": actor,
        "action": action,
        "details": details or {},
        "at": datetime.now(timezone.utc),
    }


class MemoryAuditLog:
    def __init__(self) -> None:
        self._entries: list[dict] = []

    def record(self, ticket_id, actor, action, details=None):
        self._entries.append(_entry(ticket_id, actor, action, details))

    def trail(self, ticket_id):
        return [e for e in self._entries if e["ticket_id"] == ticket_id]


class MongoAuditLog:
    def __init__(self, client=None, url: str | None = None, db_name: str = "helpdesk") -> None:
        if client is None:
            from pymongo import MongoClient

            client = MongoClient(url, serverSelectionTimeoutMS=3000)
        self._col = client[db_name]["audit_log"]
        self._col.create_index([("ticket_id", 1), ("at", 1)])

    def record(self, ticket_id, actor, action, details=None):
        self._col.insert_one(_entry(ticket_id, actor, action, details))

    def trail(self, ticket_id):
        return list(self._col.find({"ticket_id": ticket_id}, {"_id": 0}).sort("at", 1))


@lru_cache
def get_audit_log() -> AuditLog:
    if settings.MONGO_URL:
        return MongoAuditLog(url=settings.MONGO_URL, db_name=settings.MONGO_DB)
    return MemoryAuditLog()
