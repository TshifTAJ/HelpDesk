from datetime import datetime, timedelta, timezone

import jwt
from django.conf import settings
from django.contrib.auth import get_user_model

ALGORITHM = "HS256"


def create_token(user) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.JWT_MINUTES)
    return jwt.encode({"sub": user.username, "exp": exp}, settings.SECRET_KEY, algorithm=ALGORITHM)


def user_from_header(header: str | None):
    """Return the active user for an 'Authorization: Bearer <token>' header, or None."""
    if not header or not header.startswith("Bearer "):
        return None
    try:
        payload = jwt.decode(header[7:], settings.SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        return None
    User = get_user_model()
    return User.objects.filter(username=payload.get("sub"), is_active=True).first()
