from dataclasses import dataclass

from django.conf import settings
from strawberry.django.views import GraphQLView

from .auth import user_from_header


@dataclass
class Context:
    request: object
    user: object | None


class HelpDeskGraphQLView(GraphQLView):
    # GraphiQL explorer only in development.
    graphql_ide = "graphiql" if settings.DEBUG else None

    def get_context(self, request, response):
        return Context(request=request, user=user_from_header(request.headers.get("Authorization")))
