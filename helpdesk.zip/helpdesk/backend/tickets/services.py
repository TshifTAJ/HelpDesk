"""Business operations. The GraphQL layer stays thin and calls these."""
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from . import sla
from .audit import get_audit_log
from .models import Comment, Priority, Status, Ticket


class DomainError(Exception):
    """A user-correctable problem (shown to the client as the error message)."""


def visible_tickets(user):
    """Agents see every ticket; requesters only their own."""
    qs = Ticket.objects.select_related("requester", "assignee").prefetch_related("comments__author")
    return qs if user.is_staff else qs.filter(requester=user)


def search_tickets(user, status: str | None, search: str | None, page: int, page_size: int):
    qs = visible_tickets(user)
    if status:
        if status not in Status.values:
            raise DomainError(f"Unknown status '{status}'")
        qs = qs.filter(status=status)
    if search:
        qs = qs.filter(Q(title__icontains=search) | Q(description__icontains=search))
    total = qs.count()
    start = (max(page, 1) - 1) * page_size
    return list(qs[start : start + page_size]), total


@transaction.atomic
def create_ticket(user, title: str, description: str, priority: str) -> Ticket:
    title, description = title.strip(), description.strip()
    if len(title) < 3:
        raise DomainError("Title must be at least 3 characters")
    if not description:
        raise DomainError("Description is required")
    if priority not in Priority.values:
        raise DomainError(f"Priority must be one of: {', '.join(Priority.values)}")

    now = timezone.now()
    ticket = Ticket.objects.create(
        title=title,
        description=description,
        priority=priority,
        requester=user,
        created_at=now,
        sla_due_at=sla.due_at(priority, now),
    )
    get_audit_log().record(ticket.pk, user.username, "created", {"priority": priority})
    return ticket


@transaction.atomic
def change_status(agent, ticket_id: int, new_status: str) -> Ticket:
    if new_status not in Status.values:
        raise DomainError(f"Unknown status '{new_status}'")
    try:
        ticket = Ticket.objects.select_for_update().get(pk=ticket_id)
    except Ticket.DoesNotExist:
        raise DomainError("Ticket not found")
    if ticket.status == new_status:
        return ticket

    old = ticket.status
    ticket.status = new_status
    ticket.resolved_at = timezone.now() if new_status == Status.RESOLVED else None
    if new_status == Status.IN_PROGRESS and ticket.assignee is None:
        ticket.assignee = agent
    ticket.save()
    get_audit_log().record(ticket.pk, agent.username, "status_changed", {"from": old, "to": new_status})
    return ticket


@transaction.atomic
def add_comment(user, ticket_id: int, body: str) -> Comment:
    body = body.strip()
    if not body:
        raise DomainError("Comment cannot be empty")
    ticket = visible_tickets(user).filter(pk=ticket_id).first()
    if ticket is None:  # same answer for "missing" and "not yours": do not leak which tickets exist
        raise DomainError("Ticket not found")
    comment = Comment.objects.create(ticket=ticket, author=user, body=body)
    get_audit_log().record(ticket.pk, user.username, "commented")
    return comment


def sla_report(now=None) -> dict:
    now = now or timezone.now()
    tickets = list(Ticket.objects.only("status", "sla_due_at", "resolved_at"))
    resolved = [t for t in tickets if t.resolved_at is not None]
    open_tickets = [t for t in tickets if t.resolved_at is None]
    in_time = sum(1 for t in resolved if not sla.is_breached(t.sla_due_at, t.resolved_at, now))
    return {
        "total": len(tickets),
        "open": len(open_tickets),
        "breached_open": sum(1 for t in open_tickets if sla.is_breached(t.sla_due_at, None, now)),
        "resolved": len(resolved),
        "compliance_percent": sla.compliance_percent(len(resolved), in_time),
    }
