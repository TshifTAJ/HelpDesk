"""SLA rules: pure functions, no database access, easy to unit test."""
from datetime import datetime, timedelta

# Hours allowed to resolve a ticket, by priority.
SLA_HOURS = {"urgent": 4, "high": 8, "medium": 24, "low": 72}


def due_at(priority: str, created: datetime) -> datetime:
    return created + timedelta(hours=SLA_HOURS[priority])


def is_breached(sla_due_at: datetime, resolved_at: datetime | None, now: datetime) -> bool:
    """A ticket breaches its SLA if it was resolved late, or is still unresolved past its due time."""
    if resolved_at is not None:
        return resolved_at > sla_due_at
    return now > sla_due_at


def compliance_percent(total_resolved: int, resolved_in_time: int) -> float:
    """Share of resolved tickets that met their SLA. 100% when nothing has been resolved yet."""
    if total_resolved == 0:
        return 100.0
    return round(100.0 * resolved_in_time / total_resolved, 1)
