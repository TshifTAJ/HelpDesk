from django.contrib import admin

from .models import Comment, Ticket


@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("id", "title", "priority", "status", "requester", "sla_due_at")
    list_filter = ("status", "priority")
    search_fields = ("title", "description")


admin.site.register(Comment)
