from datetime import datetime

import strawberry
from django.conf import settings
from django.contrib.auth import authenticate
from django.utils import timezone
from graphql import GraphQLError
from graphql.validation import NoSchemaIntrospectionCustomRule
from strawberry.extensions import AddValidationRules, QueryDepthLimiter
from strawberry.permission import BasePermission

from . import services, sla
from .audit import get_audit_log
from .auth import create_token
from .models import Comment, Ticket


class IsAuthenticated(BasePermission):
    message = "Authentication required"

    def has_permission(self, source, info, **kwargs) -> bool:
        return info.context.user is not None


class IsAgent(BasePermission):
    message = "Agent role required"

    def has_permission(self, source, info, **kwargs) -> bool:
        user = info.context.user
        return user is not None and user.is_staff


@strawberry.type
class CommentType:
    id: strawberry.ID
    author: str
    body: str
    created_at: datetime


@strawberry.type
class TicketType:
    id: strawberry.ID
    title: str
    description: str
    priority: str
    status: str
    requester: str
    assignee: str | None
    created_at: datetime
    sla_due_at: datetime
    resolved_at: datetime | None
    sla_breached: bool
    comments: list[CommentType]


@strawberry.type
class TicketPage:
    items: list[TicketType]
    total: int
    page: int
    page_size: int


@strawberry.type
class SlaReport:
    total: int
    open: int
    breached_open: int
    resolved: int
    compliance_percent: float


@strawberry.type
class AuditEntry:
    actor: str
    action: str
    at: datetime


@strawberry.type
class AuthPayload:
    token: str
    username: str
    is_agent: bool


def to_comment(c: Comment) -> CommentType:
    return CommentType(id=strawberry.ID(str(c.pk)), author=c.author.username, body=c.body, created_at=c.created_at)


def to_ticket(t: Ticket) -> TicketType:
    return TicketType(
        id=strawberry.ID(str(t.pk)),
        title=t.title,
        description=t.description,
        priority=t.priority,
        status=t.status,
        requester=t.requester.username,
        assignee=t.assignee.username if t.assignee else None,
        created_at=t.created_at,
        sla_due_at=t.sla_due_at,
        resolved_at=t.resolved_at,
        sla_breached=sla.is_breached(t.sla_due_at, t.resolved_at, timezone.now()),
        comments=[to_comment(c) for c in t.comments.all()],  # prefetched: no N+1 queries
    )


def domain_errors(fn):
    """Turn DomainError into a clean GraphQL error message."""
    from functools import wraps

    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except services.DomainError as exc:
            raise GraphQLError(str(exc))

    return wrapper


@strawberry.type
class Query:
    @strawberry.field(permission_classes=[IsAuthenticated])
    def tickets(
        self, info: strawberry.Info, status: str | None = None, search: str | None = None, page: int = 1, page_size: int = 20
    ) -> TicketPage:
        page_size = max(1, min(page_size, 100))
        items, total = domain_errors(services.search_tickets)(info.context.user, status, search, page, page_size)
        return TicketPage(items=[to_ticket(t) for t in items], total=total, page=page, page_size=page_size)

    @strawberry.field(permission_classes=[IsAuthenticated])
    def ticket(self, info: strawberry.Info, id: strawberry.ID) -> TicketType | None:
        ticket = services.visible_tickets(info.context.user).filter(pk=int(id)).first()
        return to_ticket(ticket) if ticket else None

    @strawberry.field(permission_classes=[IsAgent])
    def sla_report(self) -> SlaReport:
        return SlaReport(**services.sla_report())

    @strawberry.field(permission_classes=[IsAgent])
    def audit_trail(self, ticket_id: strawberry.ID) -> list[AuditEntry]:
        return [
            AuditEntry(actor=e["actor"], action=e["action"], at=e["at"])
            for e in get_audit_log().trail(int(ticket_id))
        ]


@strawberry.type
class Mutation:
    @strawberry.mutation
    def login(self, username: str, password: str) -> AuthPayload:
        user = authenticate(username=username, password=password)
        if user is None:
            raise GraphQLError("Incorrect username or password")
        return AuthPayload(token=create_token(user), username=user.username, is_agent=user.is_staff)

    @strawberry.mutation(permission_classes=[IsAuthenticated])
    def create_ticket(self, info: strawberry.Info, title: str, description: str, priority: str = "medium") -> TicketType:
        ticket = domain_errors(services.create_ticket)(info.context.user, title, description, priority)
        return to_ticket(ticket)

    @strawberry.mutation(permission_classes=[IsAgent])
    def update_ticket_status(self, info: strawberry.Info, id: strawberry.ID, status: str) -> TicketType:
        ticket = domain_errors(services.change_status)(info.context.user, int(id), status)
        return to_ticket(services.visible_tickets(info.context.user).get(pk=ticket.pk))

    @strawberry.mutation(permission_classes=[IsAuthenticated])
    def add_comment(self, info: strawberry.Info, ticket_id: strawberry.ID, body: str) -> CommentType:
        comment = domain_errors(services.add_comment)(info.context.user, int(ticket_id), body)
        return to_comment(comment)


def build_schema(max_depth: int, allow_introspection: bool) -> strawberry.Schema:
    extensions = [lambda: QueryDepthLimiter(max_depth=max_depth)]
    if not allow_introspection:
        # Hide the schema from anonymous probing in production.
        extensions.append(lambda: AddValidationRules([NoSchemaIntrospectionCustomRule]))
    return strawberry.Schema(query=Query, mutation=Mutation, extensions=extensions)


schema = build_schema(settings.GRAPHQL_MAX_DEPTH, allow_introspection=settings.DEBUG)
