from .conftest import create_ticket

TICKETS = "{ tickets { total items { id requester } } }"


def test_login_success(users, gql):
    res = gql().run('mutation { login(username: "agent", password: "agent-pass") { token username isAgent } }')
    data = res["data"]["login"]
    assert data["username"] == "agent" and data["isAgent"] is True and data["token"]


def test_login_failure(users, gql):
    res = gql().run('mutation { login(username: "agent", password: "wrong") { token } }')
    assert res["errors"][0]["message"] == "Incorrect username or password"


def test_queries_require_authentication(users, gql):
    res = gql().run(TICKETS)
    assert res["errors"][0]["message"] == "Authentication required"


def test_tampered_token_is_unauthenticated(users, gql, as_alice):
    client = gql()
    client.token = as_alice.token + "x"
    assert client.run(TICKETS)["errors"][0]["message"] == "Authentication required"


def test_requesters_only_see_their_own_tickets(as_alice, as_bob, as_agent):
    create_ticket(as_alice, "Alice's issue")
    create_ticket(as_bob, "Bob's issue")

    alice_view = as_alice.run(TICKETS)["data"]["tickets"]
    assert alice_view["total"] == 1 and alice_view["items"][0]["requester"] == "alice"
    assert as_agent.run(TICKETS)["data"]["tickets"]["total"] == 2


def test_requester_cannot_fetch_someone_elses_ticket_by_id(as_alice, as_bob):
    bobs = create_ticket(as_bob)
    res = as_alice.run("query($id: ID!) { ticket(id: $id) { id } }", {"id": bobs})
    assert res["data"]["ticket"] is None


def test_requester_cannot_change_status(as_alice):
    tid = create_ticket(as_alice)
    res = as_alice.run(
        "mutation($id: ID!) { updateTicketStatus(id: $id, status: \"resolved\") { id } }", {"id": tid}
    )
    assert res["errors"][0]["message"] == "Agent role required"


def test_sla_report_and_audit_are_agent_only(as_alice):
    assert as_alice.run("{ slaReport { total } }")["errors"][0]["message"] == "Agent role required"
    assert as_alice.run('{ auditTrail(ticketId: "1") { action } }')["errors"][0]["message"] == "Agent role required"


def test_query_depth_limit_rejects_deep_queries():
    from tickets.schema import build_schema

    strict = build_schema(max_depth=2, allow_introspection=True)
    deep = "{ tickets { items { comments { author } } } }"
    result = strict.execute_sync(deep)
    assert result.errors and "depth" in str(result.errors[0]).lower()


def test_introspection_is_disabled_outside_debug(as_agent):
    res = as_agent.run("{ __schema { types { name } } }")
    assert "errors" in res and "introspection" in res["errors"][0]["message"].lower()
