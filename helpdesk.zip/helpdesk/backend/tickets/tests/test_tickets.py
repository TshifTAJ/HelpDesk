from datetime import timedelta

import pytest
from django.utils import timezone

from tickets.models import Ticket

from .conftest import create_ticket

SET_STATUS = "mutation($id: ID!, $s: String!) { updateTicketStatus(id: $id, status: $s) { status resolvedAt assignee } }"


def test_create_ticket_sets_sla_deadline(as_alice):
    tid = create_ticket(as_alice, priority="urgent")
    ticket = Ticket.objects.get(pk=tid)
    assert ticket.status == "open"
    assert ticket.sla_due_at - ticket.created_at == timedelta(hours=4)


@pytest.mark.parametrize(
    "title,description,priority,message",
    [
        ("ab", "desc", "low", "Title must be at least 3 characters"),
        ("Valid title", "   ", "low", "Description is required"),
        ("Valid title", "desc", "critical", "Priority must be one of"),
    ],
)
def test_create_ticket_validation(as_alice, title, description, priority, message):
    res = as_alice.run(
        "mutation($t: String!, $d: String!, $p: String!) { createTicket(title: $t, description: $d, priority: $p) { id } }",
        {"t": title, "d": description, "p": priority},
    )
    assert message in res["errors"][0]["message"]
    assert Ticket.objects.count() == 0


def test_agent_workflow_assigns_and_resolves(as_alice, as_agent):
    tid = create_ticket(as_alice)

    started = as_agent.run(SET_STATUS, {"id": tid, "s": "in_progress"})["data"]["updateTicketStatus"]
    assert started["status"] == "in_progress" and started["assignee"] == "agent"

    done = as_agent.run(SET_STATUS, {"id": tid, "s": "resolved"})["data"]["updateTicketStatus"]
    assert done["status"] == "resolved" and done["resolvedAt"] is not None

    reopened = as_agent.run(SET_STATUS, {"id": tid, "s": "open"})["data"]["updateTicketStatus"]
    assert reopened["resolvedAt"] is None


def test_unknown_status_and_ticket_are_rejected(as_alice, as_agent):
    tid = create_ticket(as_alice)
    assert "Unknown status" in as_agent.run(SET_STATUS, {"id": tid, "s": "bogus"})["errors"][0]["message"]
    assert "not found" in as_agent.run(SET_STATUS, {"id": "9999", "s": "open"})["errors"][0]["message"]


def test_sla_breach_flag_and_report(as_alice, as_bob, as_agent):
    late_open = create_ticket(as_alice, "Late and open", "urgent")
    late_resolved = create_ticket(as_alice, "Late but resolved", "urgent")
    on_time = create_ticket(as_bob, "Resolved quickly", "low")

    as_agent.run(SET_STATUS, {"id": on_time, "s": "resolved"})
    as_agent.run(SET_STATUS, {"id": late_resolved, "s": "resolved"})

    # Move the deadlines into the past to simulate time passing.
    past = timezone.now() - timedelta(hours=10)
    Ticket.objects.filter(pk=late_open).update(sla_due_at=past)
    Ticket.objects.filter(pk=late_resolved).update(sla_due_at=past)

    report = as_agent.run(
        "{ slaReport { total open breachedOpen resolved compliancePercent } }"
    )["data"]["slaReport"]
    assert report == {"total": 3, "open": 1, "breachedOpen": 1, "resolved": 2, "compliancePercent": 50.0}

    flags = as_agent.run("{ tickets { items { id slaBreached } } }")["data"]["tickets"]["items"]
    assert {t["id"]: t["slaBreached"] for t in flags} == {late_open: True, late_resolved: True, on_time: False}


def test_search_filter_and_pagination(as_alice):
    for i in range(5):
        create_ticket(as_alice, f"Network issue {i}")
    create_ticket(as_alice, "Password reset")

    q = "query($s: String, $st: String, $p: Int, $n: Int) { tickets(search: $s, status: $st, page: $p, pageSize: $n) { total items { title } } }"
    page = as_alice.run(q, {"s": "network", "st": None, "p": 1, "n": 2})["data"]["tickets"]
    assert page["total"] == 5 and len(page["items"]) == 2

    page3 = as_alice.run(q, {"s": "network", "st": None, "p": 3, "n": 2})["data"]["tickets"]
    assert len(page3["items"]) == 1

    assert as_alice.run(q, {"s": None, "st": "resolved", "p": 1, "n": 10})["data"]["tickets"]["total"] == 0


def test_comments_and_isolation(as_alice, as_bob, as_agent):
    tid = create_ticket(as_alice)
    add = "mutation($id: ID!, $b: String!) { addComment(ticketId: $id, body: $b) { author body } }"

    assert as_agent.run(add, {"id": tid, "b": "Looking into it"})["data"]["addComment"]["author"] == "agent"
    assert as_alice.run(add, {"id": tid, "b": "Thanks"})["data"]["addComment"]["body"] == "Thanks"
    assert "not found" in as_bob.run(add, {"id": tid, "b": "snoop"})["errors"][0]["message"]
    assert "cannot be empty" in as_alice.run(add, {"id": tid, "b": "  "})["errors"][0]["message"]

    comments = as_alice.run("query($id: ID!) { ticket(id: $id) { comments { author } } }", {"id": tid})
    assert [c["author"] for c in comments["data"]["ticket"]["comments"]] == ["agent", "alice"]


def test_listing_does_not_have_n_plus_one_queries(as_alice, as_agent, django_assert_max_num_queries):
    for i in range(8):
        tid = create_ticket(as_alice, f"Ticket {i}")
        as_agent.run("mutation($id: ID!) { addComment(ticketId: $id, body: \"hi\") { id } }", {"id": tid})

    # auth lookup + count + tickets + comments prefetch (+ prefetched authors): constant, not 8x.
    with django_assert_max_num_queries(8):
        res = as_agent.run("{ tickets { items { requester assignee comments { author } } } }")
    assert len(res["data"]["tickets"]["items"]) == 8
