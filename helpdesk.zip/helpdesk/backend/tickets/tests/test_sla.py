from datetime import datetime, timedelta, timezone

import pytest

from tickets import sla

T0 = datetime(2026, 1, 1, 8, 0, tzinfo=timezone.utc)


@pytest.mark.parametrize("priority,hours", [("urgent", 4), ("high", 8), ("medium", 24), ("low", 72)])
def test_due_at_by_priority(priority, hours):
    assert sla.due_at(priority, T0) == T0 + timedelta(hours=hours)


def test_unresolved_ticket_breaches_after_due_time():
    due = T0 + timedelta(hours=4)
    assert not sla.is_breached(due, None, T0 + timedelta(hours=3))
    assert sla.is_breached(due, None, T0 + timedelta(hours=5))


def test_resolved_ticket_is_judged_by_resolution_time_not_now():
    due = T0 + timedelta(hours=4)
    long_after = T0 + timedelta(days=30)
    assert not sla.is_breached(due, T0 + timedelta(hours=2), long_after)
    assert sla.is_breached(due, T0 + timedelta(hours=6), long_after)


def test_resolved_exactly_at_deadline_meets_sla():
    due = T0 + timedelta(hours=4)
    assert not sla.is_breached(due, due, due + timedelta(hours=1))


def test_compliance_percent():
    assert sla.compliance_percent(0, 0) == 100.0
    assert sla.compliance_percent(4, 3) == 75.0
    assert sla.compliance_percent(3, 1) == 33.3
