import json

import pytest
from django.contrib.auth import get_user_model

from tickets.audit import get_audit_log


@pytest.fixture(autouse=True)
def fresh_audit_log():
    get_audit_log.cache_clear()
    yield
    get_audit_log.cache_clear()


@pytest.fixture()
def users(db):
    User = get_user_model()
    return {
        "agent": User.objects.create_user("agent", password="agent-pass", is_staff=True),
        "alice": User.objects.create_user("alice", password="alice-pass"),
        "bob": User.objects.create_user("bob", password="bob-pass"),
    }


class GraphQLClient:
    def __init__(self, client):
        self.client = client
        self.token = None

    def login(self, username, password):
        res = self.run(
            "mutation($u: String!, $p: String!) { login(username: $u, password: $p) { token isAgent } }",
            {"u": username, "p": password},
        )
        self.token = res["data"]["login"]["token"]
        return self

    def run(self, query, variables=None):
        extra = {"HTTP_AUTHORIZATION": f"Bearer {self.token}"} if self.token else {}
        res = self.client.post(
            "/graphql",
            data=json.dumps({"query": query, "variables": variables or {}}),
            content_type="application/json",
            **extra,
        )
        return res.json()


@pytest.fixture()
def gql(client):
    return lambda: GraphQLClient(client)


@pytest.fixture()
def as_agent(client, users):
    return GraphQLClient(client).login("agent", "agent-pass")


@pytest.fixture()
def as_alice(client, users):
    return GraphQLClient(client).login("alice", "alice-pass")


@pytest.fixture()
def as_bob(client, users):
    return GraphQLClient(client).login("bob", "bob-pass")


CREATE = """
mutation($t: String!, $d: String!, $p: String!) {
  createTicket(title: $t, description: $d, priority: $p) { id status priority slaBreached }
}
"""


def create_ticket(who, title="Printer is broken", priority="medium"):
    res = who.run(CREATE, {"t": title, "d": "It jams constantly", "p": priority})
    assert "errors" not in res, res
    return res["data"]["createTicket"]["id"]
