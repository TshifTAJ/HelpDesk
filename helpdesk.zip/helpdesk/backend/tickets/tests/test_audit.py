import mongomock

from tickets.audit import MemoryAuditLog, MongoAuditLog

from .conftest import create_ticket


def test_memory_log_returns_entries_per_ticket():
    log = MemoryAuditLog()
    log.record(1, "alice", "created")
    log.record(2, "bob", "created")
    assert [e["actor"] for e in log.trail(1)] == ["alice"]


def test_mongo_log_roundtrip_in_order():
    """Runs against mongomock (no server needed); the same code talks to a real MongoDB in Docker."""
    log = MongoAuditLog(client=mongomock.MongoClient(), db_name="test")
    log.record(7, "agent", "status_changed", {"from": "open", "to": "resolved"})
    log.record(7, "agent", "commented")
    log.record(8, "agent", "created")

    trail = log.trail(7)
    assert [e["action"] for e in trail] == ["status_changed", "commented"]
    assert trail[0]["details"] == {"from": "open", "to": "resolved"}
    assert "_id" not in trail[0]


def test_graphql_writes_and_reads_audit_trail(as_alice, as_agent):
    tid = create_ticket(as_alice)
    as_agent.run('mutation($id: ID!) { updateTicketStatus(id: $id, status: "in_progress") { id } }', {"id": tid})

    trail = as_agent.run("query($id: ID!) { auditTrail(ticketId: $id) { actor action } }", {"id": tid})
    assert trail["data"]["auditTrail"] == [
        {"actor": "alice", "action": "created"},
        {"actor": "agent", "action": "status_changed"},
    ]
